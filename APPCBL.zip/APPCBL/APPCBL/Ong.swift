//
//  Ong.swift
//  APPCBL
//
//  Created by aluno on 10/06/22.
//

import Foundation
import SwiftUI

struct Ongs: Identifiable {
    let id = UUID()
    let imageName: String
    let title: String
    let Description: String
    let Description2: String
    let url: URL
}

struct OngList {
    static let OngLista = [
        Ongs(imageName: "ecotece", title: "Ecotece", Description: "O Ecotece é um Instituto do Terceiro Setor, que atua desde 2005 na promoção da cultura de sustentabilidade na moda, e um vestir consciente. Temos como missão modificar as lógicas de produção e consumo, para que a moda possa se tornar mais ética, limpa e inclusiva.",Description2: "Clique e saiba mais!" ,url: URL(string:"http://ecotece.org.br")!),
        
        Ongs(imageName:"AmigosdaTerra-logo", title: "Amigos da Terra", Description: "Desde 1994 eles defendem o “Desmatamento 0” e acreditam num modelo de desenvolvimento que não depende de atividades que provocam a perda de áreas florestais, esse promovem a possibilidade de compatibilização de produção agrícolas sem agredir a natureza.", Description2: "Clique e saiba mais!", url: URL(string: "https://amigosdaterra.org.br")!),
        
        Ongs(imageName: "lixozero", title: "Lixozero", Description: "O Instituto Lixo Zero Brasil (ILZB) é uma organização da sociedade civil autônoma, sem fins lucrativos pioneira na disseminação do conceito Lixo Zero no Brasil. Nossa missão é Articular, Mobilizar e Provocar novas atitudes nas comunidades nacionais e internacionais promovendo a prática do Lixo Zero nos diversos segmentos da sociedade.",Description2: "Clique e saiba mais!", url: URL(string: "https://ilzb.org/conceito-lixo-zero/")!),
        
        Ongs(imageName: "sustentarte", title: "Sustentarte", Description: "A Sustentarte é uma organização civil sem fins lucrativos criada com o objetivo de contribuir ativamente para a geração de uma sociedade consciente e comprometida com a construção de um planeta sustentável", Description2: "Clique e saiba mais!",url: URL(string: "https://www.atados.com.br/ong/sustentarte")!),
        
        Ongs(imageName: "costabrasilis", title: "Costa Brasilis", Description: "O Instituto Costa Brasilis tem por missão o desenvolvimento socioambiental, integrando o desenvolvimento econômico com a preservação do patrimônio natural, social e cultural da região costeira.", Description2: "Clique e saiba mais!" ,url: URL(string: "http://costabrasilis.org.br")!),
        Ongs(imageName: "regenglobal", title: "Regeneração Global", Description: "O Instituto Regeneração Global (IRG) tem como missão promover as soluções que contribuem para a regeneração do planeta e equilíbrio da sociedade. ",Description2: "Clique e saiba mais!" ,url: URL(string: "https://regeneracaoglobal.com/home")!)]
    
}
