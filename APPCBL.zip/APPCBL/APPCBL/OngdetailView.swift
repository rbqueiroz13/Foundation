//
//  OngdetailView.swift
//  APPCBL
//
//  Created by aluno on 10/06/22.
//

import SwiftUI

struct OngdetailView: View {
    var ong: Ongs
    var body: some View {
        
        VStack (spacing: 20){
            
            Spacer()
            
            Image(ong.imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 150)
                .cornerRadius(12)
            
            Text(ong.title)
                .font(.title2)
                .lineLimit(2)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            Text(ong.Description)
                .font(.body)
                .padding()
            Spacer()
            
            Link(destination: ong.url, label: {
                Text("Conheca agora")
                    .bold()
                    .font(.title2)
                    .frame(width: 280, height: 50)
                    .background(Color("laranja"))
                    .foregroundColor(.white)
                    .cornerRadius(10)
            })
        }
        
    }
}

struct OngdetailView_Previews: PreviewProvider {
    static var previews: some View {
        OngdetailView(ong: OngList.OngLista.first!)
    }
}
