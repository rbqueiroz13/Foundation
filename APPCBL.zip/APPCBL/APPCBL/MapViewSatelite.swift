//
//  MapViewSatelite.swift
//  APPCBL
//
//  Created by aluno on 28/05/22.
//

import Foundation
import SwiftUI
import UIKit
import MapKit

struct Place: Identifiable {
    let id = UUID()
    let name: String
    var coordinate = CLLocationCoordinate2D()
}

struct MapViewSatelite: UIViewRepresentable {
    
    let places: [Place] = [.init(name: "Placas, PA", coordinate: CLLocationCoordinate2D(latitude: -3.60348, longitude: -54.81586)),.init(name: "Mato Grosso", coordinate: CLLocationCoordinate2D(latitude: -13.495384, longitude: -59.266854)),.init(name: "Minas Gerais", coordinate: CLLocationCoordinate2D(latitude: -19.462937, longitude: -43.991014)),.init(name: "Nova Crixás,GO", coordinate: CLLocationCoordinate2D(latitude: -14.041789, longitude: -50.167096)),.init(name: "Agudo, RS", coordinate: CLLocationCoordinate2D(latitude: -29.793056, longitude: -53.197589
))
    
    
    
    ]
        
    
    func makeUIView(context: Context) -> MKMapView {
        MKMapView(frame: .zero)
    }
    func updateUIView(_ uiView: MKMapView, context: Context) {
        let region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: -3.60348, longitude: -54.81586),
            latitudinalMeters: CLLocationDistance(exactly: 5000000)!,
            longitudinalMeters: CLLocationDistance(exactly: 5000000)!
        )
        uiView.setRegion(region, animated: true)
        uiView.mapType = .satellite
        
        for place in places {
            let annotation = MKPointAnnotation()
            annotation.coordinate = place.coordinate
            annotation.title = place.name
            uiView.addAnnotation(annotation)
        }
        
    }
    
}
