//
//  ContentView.swift
//  AppCBL1
//
//  Created by aluno on 07/05/22.
//

import SwiftUI
import MapKit



struct HomeView: View {
    
    var body: some View {
        
        TabView {
            MapViewSatelite()
                .ignoresSafeArea(edges: [.top])
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            FavoritePlaces()
                .tabItem {
                    Image(systemName: "person")
                    Text("Perfil")
                }
            DonationView()
                .tabItem {
                    Image(systemName: "globe.asia.australia.fill")
                    Text("Ongs")
                        
                }
        }
    }
    
    struct Place: Identifiable {
        let id = UUID()
        let name: String
        var coordinate = CLLocationCoordinate2D()
    }
    
    struct MapView: View {
        @State var mapRect = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 0.3, longitude: 0.4), latitudinalMeters: .zero, longitudinalMeters: .zero)
        
        @State var annotation: [Place] = [
            Place(name: "area 1", coordinate: CLLocationCoordinate2D(latitude: -3.5678, longitude: -38.7434))
        ]
        
        
        var body: some View {
  //          NavigationView {
                ZStack {
                    Color.orange
                    Map(coordinateRegion: $mapRect, annotationItems: $annotation) { note in
                        MapAnnotation(coordinate: CLLocationCoordinate2D(latitude: -3.8755, longitude: -38.6575)) {
                            Text("df")
                        }
                    }
                                        
                }
                .edgesIgnoringSafeArea([.top])
               // .navigationTitle("Ecosion")
                .navigationBarTitleDisplayMode(.inline)
            //}
        }
    }
    
    struct Donate: View {
        var body: some View {
            Text("Donate here!")
        }
    }
    
    struct FavoritePlaces: View {
        var body: some View {
            VStack {
                VStack {
                    Image("a")
                        .resizable()
                        .frame(width: 120, height: 120)
                        .clipShape(Circle())
                    
                    Text("Admin")
                        .font(.title)
                        .bold()
                    
                    Spacer().frame(height: 30)
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: "envelope")
                            Text("myemail@email.com")
                        
                        }
                        HStack{
                            Image(systemName: "phone")
                            Text("11-1-11-1")
                            
                        }
                        HStack{
                            Image(systemName: "network")
                            Text("admin")
                        }
                    }
                    Spacer().frame(height: 30)
                   
                }
            }
        }
    }
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            HomeView()
        }
    }
}
