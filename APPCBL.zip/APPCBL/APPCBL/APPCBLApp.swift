//
//  APPCBLApp.swift
//  APPCBL
//
//  Created by aluno on 09/04/22.
//

import SwiftUI

@main
struct APPCBLApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
