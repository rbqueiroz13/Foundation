//
//  AboutView.swift
//  APPCBL
//
//  Created by aluno on 19/04/22.
//

import SwiftUI

struct AboutView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct AboutView_Previews: PreviewProvider {
    static var previews: some View {
        AboutView()
    }
}
