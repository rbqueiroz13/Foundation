//
//  Signupview.swift
//  APPCBL
//
//  Created by aluno on 12/04/22.
//

import SwiftUI

struct Signupview: View {
    @State var email = ""
    @State var senha = ""
    @State var estado = ""
    @State var cidade = ""
    var body: some View {
        VStack {
//            HStack(alignment: .center, spacing: 0, content: {
//                Text("Cadastro")
//                    .font(.title)
//                    .fontWeight(.bold)
//                    .kerning(1.9)
//                    .padding()
//                    .padding(.top, 50)
//                    Spacer()
//
//
//            })
            // E-mail
            VStack(alignment: .leading, spacing: 0, content: {
                Text("Seu email")
                    .foregroundColor(.gray)
                    .fontWeight(.semibold)
                    .padding()
            // Text Field
            TextField("joazinho123@gmail.com", text: $email)
                    .padding()
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.gray)
                    Divider()
            })
              // Senha
            VStack(alignment: .leading, spacing: 0, content: {
                Text("Senha")
                    .foregroundColor(.gray)
                    .fontWeight(.semibold)
                    .padding()
                
                // Text Field Senha
                TextField("1234567", text: $senha)
                    .foregroundColor(.gray)
                    .font(.system(size: 15, weight: .semibold))
                    .padding()
                    .background(Color.white)
                    Divider()
            })
            
            // Senha
          VStack(alignment: .leading, spacing: 0, content: {
              Text("Confirme sua senha")
                  .foregroundColor(.gray)
                  .fontWeight(.semibold)
                  .padding()
              
              // Text Field Senha
              TextField("1234567", text: $senha)
                  .foregroundColor(.gray)
                  .font(.system(size: 15, weight: .semibold))
                  .padding()
                  .background(Color.white)
                  Divider()
          })
            // Senha
          VStack(alignment: .leading, spacing: 0, content: {
              Text("Estado")
                  .foregroundColor(.gray)
                  .fontWeight(.semibold)
                  .padding()
              
              // Text Field Senha
              TextField("Digite seu estado", text: $estado)
                  .foregroundColor(.gray)
                  .font(.system(size: 15, weight: .semibold))
                  .padding()
                  .background(Color.white)
                  Divider()
          })
            // Senha
          VStack(alignment: .leading, spacing: 0, content: {
              Text("Cidade")
                  .foregroundColor(.gray)
                  .fontWeight(.semibold)
                  .padding()
              
              // Text Field Senha
              TextField("Digite sua cidade", text: $cidade)
                  .foregroundColor(.gray)
                  .font(.system(size: 15, weight: .semibold))
                  .padding()
                  .background(Color.white)
                  Divider()
          })
            // Botão de criar conta
            
            Button(
                action: {
                    print("Clicou em Cadastrar")
                },
                label: {
                    Text("Cadastrar")
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding()
                        .padding(.horizontal, 90)
                        .background(Color.blue)
                        .padding(.top,40)
                })
                Spacer()
}
}
struct Signupview_Previews: PreviewProvider {
    static var previews: some View {
        Signupview()
    }
}
    }
