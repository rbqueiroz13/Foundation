//
//  ContentView.swift
//  APPCBL
//
//  Created by aluno on 09/04/22.
//

import SwiftUI

struct ContentView: View {
    @State var email = ""
    @State var senha = ""
    
    var body: some View {
        ZStack {
            NavigationView {
                
                //           ScrollView{
                ZStack{
                    
                    ZStack {
                        Color("laranja")
                            .edgesIgnoringSafeArea(.top)
                        Image("ecosion")
                            .resizable()
                            .frame(width: 200, height: 200)
                            .offset(y: 35)
                    }
                    .padding(.bottom, 900)
                    
                    
                    VStack{
                        
                        
                        
                        
                        //             Text("Ecosion")
                        //                  .font(.title)
                        //              .fontWeight(.bold)
                        //                // Espacamento de letras
                        //                    .kerning(1.9)
                        //             .frame(maxWidth: .infinity, alignment: .leading)
                        //           .padding()
                        
                        // E-mail e senha
                        VStack(alignment: .leading, spacing: 8, content: {
                            
                            Text("Nome de Usuário")
                                .fontWeight(.bold)
                                .foregroundColor(.gray)
                            
                            TextField("seuemail@gmail.com", text: $email)
                            // Mudando a fonte
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.gray)
                                .padding(.top,5)
                            
                            
                            
                            
                            Divider()
                            
                            
                        })
                            .padding()
                            .padding(.top,20)
                        
                        // Senha
                        
                        VStack(alignment: .leading, spacing: 8, content: {
                            
                            Text("Sua senha de usuario")
                                .fontWeight(.bold)
                                .foregroundColor(.gray)
                            
                            SecureField("123456", text: $senha)
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.gray)
                                .padding(.top,5)
                            Divider()
                            
                        })
                            .padding()
                        
                        // Esqueceu sua senha?
                        NavigationLink(
                            destination: {
                                ForgotPasswordView()
                                    .navigationTitle("Mude sua senha")
                                
                            },
                            label: {
                                Text("Esqueceu sua senha?")
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding()
                                
                                
                                
                            }
                        )
                        //                Button(
                        //                    action: {
                        //                        print("Clicou em esqueceu a senha")
                        //                    },
                        //                    label: {
                        //                        Text("Esqueceu sua senha?")
                        //                            .frame(maxWidth: .infinity, alignment: .leading)
                        //                            .padding()
                        //                    }
                        //                )
                        
                        // Botão de login
                        NavigationLink(
                            destination: {
                                HomeView()
                            },
                            label: {
                                Text("Entrar")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .padding(.horizontal, 90)
                                    .background(Color.blue)
                                    .padding(.top, 40)
                                
                                
                                
                                
                            }
                        )
                        //                Button(
                        //                    action: {
                        //                        print("Clicou em Entrar")
                        //                    },
                        //                    label: {
                        //                        Text("Entrar")
                        //                            .fontWeight(.bold)
                        //                            .foregroundColor(.white)
                        //                            .padding()
                        //                            .padding(.horizontal, 90)
                        //                            .background(Color.blue)
                        //                            .padding(.top,40)
                        //                    }
                        //                )
                        //
                        // Botão de cadastro
                        NavigationLink(
                            destination: {
                                Signupview()
                                    .navigationTitle("Cadastro")
                                //print("Clicou em cadastro")
                            },
                            label: {
                                Text("Novo por aqui? Cadastre-se!")
                                //.font(.system(size: 12, weight: .bold))
                                //.foregroundColor(.blue)
                                //.padding(.top, 20)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding()
                                    .padding(.top, 150)
                            }
                        )
                        
                        
                        // Botão sobre o aplicativo
                        NavigationLink(
                            destination: {
                                AboutView()
                                    .navigationTitle("Informações")
                            },
                            label: {
                                Text("Sobre o App")
                                    .frame(maxWidth: .infinity,
                                           alignment: .leading)
                                    .padding()
                            }
                        )
                        //Text("Sobre")
                    }
                }
            }
        }
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
                .previewInterfaceOrientation(.portraitUpsideDown)
        }
    }
}

//}

