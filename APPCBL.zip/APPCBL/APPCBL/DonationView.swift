//
//  DonationView.swift
//  APPCBL
//
//  Created by aluno on 10/06/22.
//

import SwiftUI

struct DonationView: View {
    var ongs: [Ongs] = OngList.OngLista
    var body: some View {
//        NavigationView {
            List(ongs, id: \.id) { ong in
                NavigationLink(destination: OngdetailView(ong: ong), label: {
                    Image(ong.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 70)
                        .cornerRadius(4)
                        .padding(.vertical, 4)
                    VStack(alignment: .leading, spacing: 5) {
                        Text(ong.title)
                            .fontWeight(.semibold)
                            .minimumScaleFactor(0.5)
                        Text(ong.Description2)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                })
                    .navigationTitle("ONGS Ambientais.")
                
            }
//        }
    }
    
    
    struct DonationView_Previews: PreviewProvider {
        static var previews: some View {
            DonationView()
        }
    }
}

